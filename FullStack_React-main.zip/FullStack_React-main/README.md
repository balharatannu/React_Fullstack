# FullStack_React

# FULLSTACK Assignment

## 1 Live Character Counter for Textarea 
**Output:**  
![Live Character Counter for Textarea](https://github.com/user-attachments/assets/7481bf0d-8c0f-4e3a-b7ce-4b7f9ede985e)
---

## 2 Library Management UI with Search, Add, and Remove Book Functionality  
**Output:**  
![Library Management UI with Search, Add, and Remove Book Functionality](https://github.com/user-attachments/assets/fb3f6408-73c7-48f7-aff9-af22d46f5320)

---

## 3 Person Class Hierarchy with Student and Teacher Subclasses  
**Output:**  
![Person Class Hierarchy with Student and Teacher Subclasses](https://github.com/user-attachments/assets/3e55dc0f-3ec4-41f7-be48-d2c3c9f26ab7)
